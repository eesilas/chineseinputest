/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Keyboard, 
  Trophy, 
  RefreshCcw, 
  Volume2, 
  VolumeX, 
  CheckCircle2, 
  AlertCircle,
  Settings2,
  ChevronRight,
  BookOpen
} from "lucide-react";
import confetti from "canvas-confetti";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { CHARACTER_DATA, type ChineseCharacter } from "./data/characters";

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [currentLevel, setCurrentLevel] = useState(1);
  const [levelData, setLevelData] = useState<ChineseCharacter[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [inputValue, setInputValue] = useState("");
  const [stats, setStats] = useState({ correct: 0, total: 0, startTime: 0 });
  const [isMuted, setIsMuted] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Filter data by level
  useEffect(() => {
    const filtered = CHARACTER_DATA.filter(c => c.level === currentLevel);
    // Shuffle level data
    const shuffled = [...filtered].sort(() => Math.random() - 0.5);
    setLevelData(shuffled);
    setCurrentIndex(0);
    setInputValue("");
    setStats({ correct: 0, total: 0, startTime: 0 });
    setIsFinished(false);
  }, [currentLevel]);

  const currentTask = levelData[currentIndex];

  const handleSpeak = useCallback((text: string) => {
    if (isMuted) return;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "zh-CN";
    window.speechSynthesis.speak(utterance);
  }, [isMuted]);

  useEffect(() => {
    if (currentTask) {
      handleSpeak(currentTask.char);
    }
  }, [currentTask, handleSpeak]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.toLowerCase().trim();
    setInputValue(val);

    if (!stats.startTime && val.length > 0) {
      setStats(prev => ({ ...prev, startTime: Date.now() }));
    }

    if (val === currentTask?.pinyin) {
      handleCorrect();
    }
  };

  const handleCorrect = () => {
    setStats(prev => ({ ...prev, correct: prev.correct + 1, total: prev.total + 1 }));
    setInputValue("");
    
    if (currentIndex < levelData.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      handleFinish();
    }
  };

  const handleFinish = () => {
    setIsFinished(true);
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  const resetSession = () => {
    const shuffled = [...levelData].sort(() => Math.random() - 0.5);
    setLevelData(shuffled);
    setCurrentIndex(0);
    setInputValue("");
    setStats({ correct: 0, total: 0, startTime: 0 });
    setIsFinished(false);
  };

  const calculateWPM = () => {
    if (!stats.startTime) return 0;
    const durationMinutes = (Date.now() - stats.startTime) / 60000;
    if (durationMinutes === 0) return 0;
    return Math.round(stats.correct / durationMinutes);
  };

  const calculateAccuracy = () => {
    if (stats.total === 0) return 0;
    return Math.round((stats.correct / stats.total) * 100);
  };

  return (
    <div className="min-h-screen bg-slate-50 relative selection:bg-azure-100 selection:text-azure-900">
      {/* Background Image with Overlay */}
      <div 
        className="fixed inset-0 z-0 opacity-20"
        style={{ 
          backgroundImage: `url('/src/assets/images/chinese_learning_bg_1793409828766.jpg')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 py-8">
        {/* Navigation Contract */}
        {/* Navigation Contract: 3 Zones */}
        <header className="flex items-center justify-between gap-8 py-4 border-b border-slate-200 mb-12">
          {/* Zone 1: Brand */}
          <a href="/" className="text-2xl font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 flex items-center gap-2">
            <Keyboard className="w-8 h-8 text-azure-600" />
            Hanzi Type
          </a>

          {/* Zone 2: Nav Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
            <button onClick={() => setCurrentLevel(1)} className={cn("hover:text-slate-900 transition-colors whitespace-nowrap", currentLevel === 1 && "text-azure-600 underline underline-offset-4 cursor-pointer")}>HSK 1</button>
            <button onClick={() => setCurrentLevel(2)} className={cn("hover:text-slate-900 transition-colors whitespace-nowrap", currentLevel === 2 && "text-azure-600 underline underline-offset-4 cursor-pointer")}>HSK 2</button>
            <a href="#" className="hover:text-slate-900 transition-colors whitespace-nowrap">Learn Rules</a>
            <a href="#" className="hover:text-slate-900 transition-colors whitespace-nowrap">Daily Practice</a>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center gap-4 shrink-0">
            <button className="px-5 py-2.5 text-sm font-medium text-white bg-slate-900 rounded-xl hover:bg-slate-800 transition-all shadow-sm active:scale-95">
              Sign In
            </button>
          </div>
        </header>

        {/* Main Content: Two-Zone Sandbox */}
        <main className="grid lg:grid-cols-[1fr,380px] gap-12 items-start">
          
          {/* Interactive Stage (Left) */}
          <section className="space-y-8">
            <AnimatePresence mode="wait">
              {!isFinished ? (
                <motion.div 
                  key="typing-stage"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-white/80 backdrop-blur-md rounded-3xl p-12 border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col items-center justify-center min-h-[500px] relative"
                >
                  {/* Floating Micro-controls in Stage */}
                  <div className="absolute top-6 right-6 flex items-center gap-2">
                    <button 
                      onClick={() => setIsMuted(!isMuted)}
                      className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                      title={isMuted ? "Unmute" : "Mute"}
                    >
                      {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                    </button>
                    <button 
                      onClick={() => setShowSettings(!showSettings)}
                      className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                    >
                      <Settings2 className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="text-center space-y-6 mb-12">
                    <motion.div 
                      key={currentTask?.char}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="text-9xl font-chinese font-bold text-slate-900 tracking-wider mb-2"
                    >
                      {currentTask?.char}
                    </motion.div>
                    <div className="text-xl text-slate-500 font-medium">
                      {currentTask?.meaning}
                    </div>
                  </div>

                  <div className="w-full max-w-md relative">
                    <input
                      ref={inputRef}
                      autoFocus
                      type="text"
                      value={inputValue}
                      onChange={handleInputChange}
                      placeholder="Type the Pinyin..."
                      className="w-full text-center text-4xl font-display font-medium py-6 px-4 bg-slate-100/50 border-2 border-slate-200 rounded-2xl focus:outline-none focus:border-azure-500 focus:ring-4 focus:ring-azure-500/10 transition-all placeholder:text-slate-300 uppercase"
                    />
                    
                    {/* Character hint revealed after delay or attempt */}
                    {inputValue.length > 2 && currentTask?.pinyin.startsWith(inputValue) === false && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="mt-4 flex items-center justify-center gap-2 text-red-500 font-medium"
                      >
                        <AlertCircle className="w-4 h-4" />
                        Hint: {currentTask.pinyin[0]}...
                      </motion.div>
                    )}
                  </div>

                  {/* Progress Indicator */}
                  <div className="mt-12 w-full max-w-sm space-y-2">
                    <div className="flex justify-between text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      <span>Progress</span>
                      <span>{currentIndex + 1} / {levelData.length}</span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${((currentIndex + 1) / levelData.length) * 100}%` }}
                        className="h-full bg-azure-500"
                      />
                    </div>
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  key="results-stage"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-white rounded-3xl p-16 border border-slate-200 shadow-xl text-center space-y-8"
                >
                  <div className="inline-flex p-6 rounded-full bg-amber-50 text-amber-500 mb-4">
                    <Trophy className="w-16 h-16" />
                  </div>
                  <h2 className="text-4xl font-bold text-slate-900">Level Complete!</h2>
                  <p className="text-lg text-slate-500 max-w-md mx-auto">
                    You've mastered {levelData.length} characters in HSK {currentLevel}. Keep it up!
                  </p>
                  
                  <div className="grid grid-cols-2 gap-6 max-w-sm mx-auto py-8">
                    <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
                      <div className="text-3xl font-bold text-slate-900">{calculateWPM()}</div>
                      <div className="text-xs text-slate-400 uppercase tracking-widest font-bold mt-1">Chars/Min</div>
                    </div>
                    <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
                      <div className="text-3xl font-bold text-slate-900">{calculateAccuracy()}%</div>
                      <div className="text-xs text-slate-400 uppercase tracking-widest font-bold mt-1">Accuracy</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-4">
                    <button 
                      onClick={resetSession}
                      className="flex items-center gap-2 px-8 py-4 bg-slate-900 text-white rounded-2xl font-semibold hover:bg-slate-800 transition-all active:scale-95 shadow-lg shadow-slate-200"
                    >
                      <RefreshCcw className="w-5 h-5" />
                      Try Again
                    </button>
                    <button 
                      onClick={() => setCurrentLevel(currentLevel === 1 ? 2 : 1)}
                      className="flex items-center gap-2 px-8 py-4 bg-white border border-slate-200 text-slate-900 rounded-2xl font-semibold hover:bg-slate-50 transition-all active:scale-95"
                    >
                      Next Level
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </section>

          {/* Control & Concept Deck (Right) */}
          <aside className="space-y-6">
            <div className="bg-white/60 backdrop-blur-sm border border-slate-200 rounded-3xl p-8 space-y-8">
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  Live Performance
                </h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <span className="text-sm text-slate-500">Characters/Min</span>
                    <span className="text-2xl font-mono tabular-nums font-bold text-slate-900">{calculateWPM()}</span>
                  </div>
                  <div className="flex justify-between items-end">
                    <span className="text-sm text-slate-500">Accuracy</span>
                    <span className="text-2xl font-mono tabular-nums font-bold text-slate-900">{calculateAccuracy()}%</span>
                  </div>
                  <div className="flex justify-between items-end">
                    <span className="text-sm text-slate-500">Correct</span>
                    <span className="text-2xl font-mono tabular-nums font-bold text-slate-900">{stats.correct}</span>
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-slate-100">
                <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-azure-500" />
                  Today's Goal
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Complete 50 characters to maintain your streak. You're currently at {stats.correct}/50.
                </p>
                <div className="mt-4 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-amber-400" 
                    style={{ width: `${Math.min(100, (stats.correct / 50) * 100)}%` }}
                  />
                </div>
              </div>

              <div className="pt-8 border-t border-slate-100">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Quick Shortcuts</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Reset Level</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded text-slate-600 font-mono">Esc</kbd>
                  </div>
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Next Character</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded text-slate-600 font-mono">Enter</kbd>
                  </div>
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Hear Character</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-100 border border-slate-200 rounded text-slate-600 font-mono">Space</kbd>
                  </div>
                </div>
              </div>
            </div>

            {/* Support Message */}
            <div className="p-6 bg-azure-50 rounded-2xl border border-azure-100">
              <p className="text-xs text-azure-700 leading-relaxed">
                <span className="font-bold block mb-1">Pro Tip:</span>
                Focus on accuracy first. Speed will naturally improve as you build muscle memory for the Pinyin patterns.
              </p>
            </div>
          </aside>
        </main>

        {/* Footer */}
        <footer className="mt-20 py-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-400">
          <p>© 2026 Hanzi Type. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-slate-600">Privacy Policy</a>
            <a href="#" className="hover:text-slate-600">Terms of Service</a>
            <a href="#" className="hover:text-slate-600">Contact Us</a>
          </div>
        </footer>
      </div>

      {/* Global Event Listeners for Shortcuts */}
      <KeyboardShortcuts onReset={resetSession} onSpeak={() => handleSpeak(currentTask?.char || "")} />
    </div>
  );
}

function KeyboardShortcuts({ onReset, onSpeak }: { onReset: () => void, onSpeak: () => void }) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onReset();
      if (e.key === " " && (e.target as HTMLElement).tagName !== "INPUT") {
        e.preventDefault();
        onSpeak();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onReset, onSpeak]);
  return null;
}
